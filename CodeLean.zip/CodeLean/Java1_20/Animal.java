package CodeLean.Java1_20;

abstract public class Animal {
    abstract public void greeting();
}