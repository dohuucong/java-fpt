package CodeLean.Java1_20;

public interface GeometricObject {
    public double getPerimeter();
    public double getArea();
}
