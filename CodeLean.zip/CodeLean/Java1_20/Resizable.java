package CodeLean.Java1_20;

public interface Resizable {
    void resize(int percent);
}
