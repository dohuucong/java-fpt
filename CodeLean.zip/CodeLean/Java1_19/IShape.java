package CodeLean.Java1_19;

public interface IShape {
    double getPerimeter();
}
