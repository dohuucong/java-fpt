package Book;

public class Session_02 {
    public static void main(String[] args) {
        System.out.println("Welcome to the world of Java");
    }
}
